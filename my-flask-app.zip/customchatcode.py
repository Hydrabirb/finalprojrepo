from dotenv import load_dotenv
import os

from langchain.text_splitter import CharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
#from langchain.chains.question_answering import load_qa_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.document_loaders import SpiderLoader
from langchain_openai import OpenAI

load_dotenv()

def readFile(filePath):
    f = open(filePath, encoding="utf8")
    text = f.read()
    f.close()
    
    return text

# split into chunks
char_text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, 
                                      chunk_overlap=200, length_function=len)



text_chunks = []
num = 0;
try:
    cwd = os.getcwd()
    if len(os.listdir((os.path.join(cwd, "EldenRingScrape")))) == 0:
        filePath = os.path.join(cwd, "EldenRingScrape", "eldenRingFile")
        loader = SpiderLoader( api_key="sk-e81820d0-69e0-45c8-8e47-a809693c73be", url = "https://eldenring.wiki.fextralife.com/", mode="crawl", params={"return_format":"markdown", "readability":True, "metadata":True, "locale":"en_US"})
        data = loader.load()
        
        for page in data:
            
            text = page.page_content
            f = open(filePath + str(num) + ".txt", "x")
            f.write(page.page_content)
            f.close()
            num += 1
            
            chunks = char_text_splitter.split_text(text)
            
            text_chunks.extend(chunks)
    else:
        directory = os.path.join(cwd, "EldenRingScrape")
        for page in os.listdir(directory):
            filePath = os.path.join(directory, page)
            
            text = readFile(filePath)
            
            chunks = char_text_splitter.split_text(text)
            
            text_chunks.extend(chunks)
except:
    print("An exception occurred")


# create embeddings
embeddings = OpenAIEmbeddings()
docsearch = FAISS.from_texts(text_chunks, embeddings)

# Define the prompt template
prompt_template = ChatPromptTemplate.from_messages(
    [("system", "You are a helpful assistant. Here is the information you have:\n\n{context}\n\nAnswer the following question based on the information above:\n\nQuestion: {question}\nAnswer:")]
)
llm = OpenAI()
#chain = load_qa_chain(llm, chain_type="stuff")
chain = create_stuff_documents_chain(llm, prompt_template)
##################################################

# Ask a question
#query  = "What is the significance of 42?"
query  = "Who is morgott?"

docs = docsearch.similarity_search(query)
#print(hasattr(docs[0], 'page_content'))

response = chain.invoke({"context": docs, "question": query})
print(" ")
print("Query:", query)
print("Response:", response)
  
#If you want to keep track of your spending
#with get_openai_callback() as cb:
   # response = chain.run(input_documents=docs, question=query ) 
  #  print(cb)

