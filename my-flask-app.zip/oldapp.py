from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os
from langchain.text_splitter import CharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.document_loaders import SpiderLoader
from langchain_openai import OpenAI
from flask_cors import CORS

load_dotenv()

app = Flask(__name__)
CORS(app)

def read_file(file_path):
    try:
        with open(file_path, encoding="utf8") as file:
            return file.read()
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
        return None
    except IOError as e:
        print(f"Error: An IOError occurred - {e}")
        return None
    
# split into chunks
char_text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, 
                                      chunk_overlap=200, length_function=len)

def process_text():
    text_chunks = []
    num = 0
    cwd = os.getcwd()
    directory = os.path.join(cwd, "EldenRingScrape")

    try:
        if len(os.listdir(directory)) == 0:
            file_path = os.path.join(directory, "eldenRingFile")
            loader = SpiderLoader(
                #api_key="sk-e81820d0-69e0-45c8-8e47-a809693c73be", 
                url="https://eldenring.wiki.fextralife.com/", 
                mode="crawl", 
                params={"return_format":"markdown", "readability":True, "metadata":True, "locale":"en_US"}
            )
            data = loader.load()

            for page in data:
                text = page.page_content
                with open(file_path + str(num) + ".txt", "x") as file:
                    file.write(page.page_content)
                num += 1

                chunks = char_text_splitter.split_text(text)
                text_chunks.extend(chunks)
        else:
            print(directory)
            for page in os.listdir(directory):
                file_path = os.path.join(directory, page)
                text = read_file(file_path)
                chunks = char_text_splitter.split_text(text)
                text_chunks.extend(chunks)

    except Exception as e:
        print("An exception occurred:", e)

    # Create embeddings
    embeddings = OpenAIEmbeddings()
    docsearch = FAISS.from_texts(text_chunks, embeddings)

    # Define the prompt template
    prompt_template = ChatPromptTemplate.from_messages(
        [("system", "You are a helpful assistant. Here is the information you have:\n\n{context}\n\nAs well as the previous interactions:\n\n{history}\n\nAnswer the following question based on the information above and the previous interactions:\n\nQuestion: {question}\nAnswer:")]
       # [("system", "You are a helpful assistant. Here is the information you have:\n\n{context}\n\nAnswer the following question based on the information above:\n\nQuestion: {question}\nAnswer:")]
    )
    llm = OpenAI()
    chain = create_stuff_documents_chain(llm, prompt_template)

    return docsearch, chain

# Global variables for document search and chain
docsearch, chain = process_text()

# In-memory store for past interactions
history = []
questionNum = 1

@app.route('/ask', methods=['GET'])
def ask_question():
    global questionNum
    query = request.args.get('query')
    if not query:
        return jsonify({"error": "Query parameter is missing"}), 400
    
    history.append({"questionNumber": questionNum,"question": query, "answer": None})
    questionNum += 1
    print(questionNum)

    docs = docsearch.similarity_search(query)
  #  print(type(docs))
    response = chain.invoke({"context": docs, "history": history, "question": query})
    
    history[-1]["answer"] = response
 #   print(history[-1])

    return jsonify({
        "query": query,
        "response": response
    })

if __name__ == "__main__":
    app.run(debug=False)
    
